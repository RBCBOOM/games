Reflect.defineProperty(Document.prototype, 'domain', {
	get: () => 'player03.com',
});
